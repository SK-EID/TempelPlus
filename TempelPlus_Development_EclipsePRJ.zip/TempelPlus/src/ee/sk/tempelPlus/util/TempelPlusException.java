package ee.sk.tempelPlus.util;

public class TempelPlusException extends Exception {

   public TempelPlusException(String s){
      super(s);
   }

}
