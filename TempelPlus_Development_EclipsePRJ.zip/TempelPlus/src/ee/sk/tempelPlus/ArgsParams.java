package ee.sk.tempelPlus;

public class ArgsParams
{
   public String Params = "";
   public int i = 0;
}
