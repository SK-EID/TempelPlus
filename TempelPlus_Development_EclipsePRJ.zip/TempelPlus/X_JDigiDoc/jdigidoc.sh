#!/bin/bash
JDTEST=./lib
CLASSPATH=$JDTEST/bcprov-jdk14-133.jar:$JDTEST/jakarta-log4j-1.2.6.jar:$JDTEST/iaikPkcs11Wrapper.jar:./tinyxmlcanonicalizer-0.9.0.jar:classes:.:$JDTEST/bctsp-jdk14-133.jar
echo $CLASSPATH
#JAVA_HOME=/opt/j2sdk1.4.2_09
#JAVA_HOME=/usr/java/jdk1.5.0_09
#JAVA_HOME=/opt/jdk1.5.0_05
export JAVA_HOME=/System/Library/Frameworks/JavaVM.framework/Versions/1.4.2/Home
$JAVA_HOME/bin/java -Xmx512m -classpath $CLASSPATH ee.sk.test.jdigidoc -config jar://jdigidoc.cfg $1 $2 $3 $4 $5 $6 $7 $8 $9 $10
