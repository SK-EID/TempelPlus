#!/bin/bash
export JAVA_HOME=/System/Library/Frameworks/JavaVM.framework/Versions/1.4.2/Home/
export CLASSPATH=../lib/bcprov-jdk14-133.jar:../lib/bctsp-jdk14-133.jar:../lib/iaik_jce.jar:../lib/iaikPkcs11Wrapper.jar:../lib/jakarta-log4j-1.2.6.jar:../lib/xalan.jar:../lib/xercesImpl.jar:../lib/xml-apis.jar:../lib/xmlParserAPIs.jar:../lib/xmlsec.jar:../classes/
$JAVA_HOME/bin/javac -d ../classes ee/sk/utils/*.java ee/sk/test/*.java ee/sk/digidoc/*.java ee/sk/digidoc/factory/*.java ee/sk/xmlenc/*.java ee/sk/xmlenc/factory/*.java
