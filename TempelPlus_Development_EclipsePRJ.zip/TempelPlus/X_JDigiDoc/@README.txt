jdigidoc utility sample use cases:

### Prerequisites - review jdigidoc.bat to match your system settings ###

- line 2: set JDIGIDOC_HOME to the folder containing this @README.txt file
- line 2: depending on your java version, you may have to try other version of bcprov*.jar instead of bcprov-jdk14-133.jar from lib folder
- line 4: set your java binaries folder
- line 4: jdigidoc-win.cfg config file is used by default - review variable values in jdigidoc-win.cfg!



### Creating new ddoc container, an example ###

c:\temp\JDigiDoc>jdigidoc.bat -ddoc-new -ddoc-add C:\temp\test1.txt text/plain -ddoc-sign 01497 -ddoc-out c:\temp\test1.ddoc

- C:\temp\test1.txt	- a datafile to be added to ddoc container
- 01497			- id-card pin2
- c:\temp\test1.ddoc	- ddoc container to be created




### Validating existing ddoc container ###

c:\temp\JDigiDoc>jdigidoc.bat -ddoc-in C:\temp\test1.ddoc -ddoc-validate -ddoc-list