package ee.sk.digidoc.c14n;

import ee.sk.digidoc.c14n.TinyXMLParser_Element;
import ee.sk.digidoc.c14n.TinyXMLParser_Handler;

public class TinyXMLParser_Document
{
    public TinyXMLParser_Handler ParseHandler;
    public TinyXMLParser_Element DocumentElement;


    public TinyXMLParser_Document()
    {
    }



}
