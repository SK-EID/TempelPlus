package ee.sk.digidoc.c14n;

import ee.sk.digidoc.c14n.TinyXMLParser_Node;
import ee.sk.digidoc.c14n.TinyXMLParser_Tag;

public final class TinyXMLParser_Comment extends TinyXMLParser_Node
{
    public TinyXMLParser_Tag ValueTag;


    public TinyXMLParser_Comment()
    {
        super();
    }



}
