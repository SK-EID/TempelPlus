#!/bin/bash
JDTEST=/home/veiko/workspace/JDigiDoc/lib
CLASSPATH=/home/veiko/workspace/JDigiDoc:$JDTEST/bcprov-jdk14-125.jar:$JDTEST/jakarta-log4j-1.2.6.jar:$JDTEST/xalan.jar:$JDTEST/xercesImpl.jar:$JDTEST/xml-apis.jar:$JDTEST/xmlParserAPIs.jar:$JDTEST/xmlsec.jar
echo $CLASSPATH
JAVA_HOME=/opt/j2sdk1.4.2_06
$JAVA_HOME/bin/java -Xmx512m -classpath $CLASSPATH ee.sk.test.ParseTest /home/veiko/workspace/JDigiDoc/jdigidoc.cfg $1
