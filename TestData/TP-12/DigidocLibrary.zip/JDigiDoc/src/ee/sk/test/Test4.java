/*
 * Test4.java
 *
 * Created on den 16 januari 2003, 11:36
 */

package ee.sk.test;
import java.util.*;

/**
 *
 * @author  B16019
 * @version 
 */
public class Test4 {

    public static void main(String[] args) {
        Properties props = System.getProperties();
        props.list(System.out);
    }
}
